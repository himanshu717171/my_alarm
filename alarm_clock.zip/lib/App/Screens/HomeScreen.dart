import 'package:alarm_clock/App/Screens/PuzzleScreen.dart';
import 'package:alarm_clock/App/Widgets/ThemeData.dart';
import 'package:alarm_clock/App/Widgets/Data.dart';
import 'package:alarm_clock/App/Widgets/EnumsData.dart';
import 'package:alarm_clock/App/Widgets/MenuInfo.dart';
import 'package:alarm_clock/App/Screens/AlarmScreen.dart';
import 'package:alarm_clock/App/Screens/ClockScreen.dart';
import 'package:alarm_clock/App/Screens/TimerScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:alarm_clock/App/Screens/StopwatchScreen.dart';
import 'package:rxdart/rxdart.dart';

class Home extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.pageBackgroundColor,
      body: Row(
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: menuItems
                .map((currentMenuInfo) => buildMenuButton(currentMenuInfo))
                .toList(),
          ),
          VerticalDivider(
            color: CustomColors.dividerColor,
            width: 1,
          ),
          Expanded(
            child: Consumer<MenuInfo>(
              builder: (BuildContext context, MenuInfo value, Widget child) {
                if (value.menuType == MenuType.clock)
                  return Clock();
                else if (value.menuType == MenuType.alarm)
                  return Alarm();
                else if (value.menuType == MenuType.timer)
                  return TimerView();
                else if (value.menuType == MenuType.stopwatch)
                  return StopWatch();
                return Container(
                  child: RichText(
                    text: TextSpan(
                      style: TextStyle(fontSize: 20),
                      children: <TextSpan>[
                        TextSpan(text: 'In Progress'),
                        TextSpan(
                          text: value.title,
                          style: TextStyle(fontSize: 48),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ignore: close_sinks
  final BehaviorSubject<String> selectNotificationSubject =
      BehaviorSubject<String>();

  void _configureSelectNotificationSubject() {
    selectNotificationSubject.stream.listen((String payload) async {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Puzzle()),
      );
    });
    // print('Home');
  }

  void initState() {
    super.initState();
    _configureSelectNotificationSubject();
  }

  Widget buildMenuButton(MenuInfo currentMenuInfo) {
    return Consumer<MenuInfo>(
      builder: (BuildContext context, MenuInfo value, Widget child) {
        return FlatButton(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(topRight: Radius.circular(32))),
          padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 0),
          color: currentMenuInfo.menuType == value.menuType
              ? CustomColors.menuBackgroundColor
              : Colors.transparent,
          onPressed: () {
            var menuInfo = Provider.of<MenuInfo>(context, listen: false);
            menuInfo.updateMenuInfo(currentMenuInfo);
          },
          child: Column(
            children: <Widget>[
              Image.asset(
                currentMenuInfo.imageSource,
                scale: 1.5,
              ),
              SizedBox(height: 16),
              Text(
                currentMenuInfo.title ?? '',
                style: TextStyle(
                    fontFamily: 'avenir',
                    color: CustomColors.primaryTextColor,
                    fontSize: 14),
              ),
            ],
          ),
        );
      },
    );
  }
}
