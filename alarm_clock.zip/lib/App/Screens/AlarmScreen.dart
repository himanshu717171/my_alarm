import 'package:alarm_clock/App/Screens/PuzzleScreen.dart';
import 'package:alarm_clock/App/Widgets/AlarmHelper.dart';
import 'package:alarm_clock/App/Widgets/ThemeData.dart';
import 'package:alarm_clock/App/Widgets/AlarmInfo.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:alarm_clock/App/Widgets/Data.dart';
import 'package:flutter_shake_plugin/flutter_shake_plugin.dart';
import 'package:alarm_clock/main.dart';
import 'package:ringtone/ringtone.dart';
import 'package:rxdart/rxdart.dart';
import 'dart:isolate';
import 'dart:math';
import 'dart:ui';
import 'package:android_alarm_manager/android_alarm_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';

class Alarm extends StatefulWidget {
  @override
  _AlarmPageState createState() => _AlarmPageState();
}

final BehaviorSubject<String> selectNotificationSubject =
    BehaviorSubject<String>();

//   private static AtomicBoolean sIsIsolateRunning = new AtomicBoolean(false);

class _AlarmPageState extends State<Alarm> {
  FlutterShakePlugin _shakePlugin;
  DateTime currentTime;
  DateTime _alarmTime;
  String _alarmTimeString;
  AlarmHelper _alarmHelper = AlarmHelper();
  Future<List<AlarmInfo>> _alarms;

  @override
  void initState() {
    // _shakePlugin = FlutterShakePlugin(
    //   onPhoneShaken: () {
    //     //do stuff on phone shake
    //     cancelNotification('0');
    //   },
    // )..startListening();
    currentTime = DateTime.now();
    _alarmTime = DateTime.now();
    _alarmHelper.initializeDatabase().then((value) {
      print('------database intialized');
      loadAlarms();
    });
    super.initState();
    print('Current Time :');
    print(currentTime);

    print('Alarm Time');
    print(_alarmTime);
    // _configureSelectNotificationSubject();
    AndroidAlarmManager.initialize();
    // androidAlarm();
  }

  void dispose() {
    super.dispose();
    _shakePlugin.stopListening();
  }

  void loadAlarms() {
    _alarms = _alarmHelper.getAlarms();
    if (mounted) setState(() {});
  }

  void addMessage() {
    showAlertDialog(context);
  }

  void deleteMessage() {
    showAlertDialogdelete(context);
  }

  showAlertDialog(BuildContext context) {
    // Create button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    // Create AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Alert"),
      content: Text("Alarm Added"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void _configureSelectNotificationSubject() {
    selectNotificationSubject.stream.listen((String payload) async {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Puzzle()),
      );
    });
    print('Alarm Ring');
  }

  setOnNotificationClick(Function onNotificationClick) async {
    var initializationSettings;
    await flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String payload) async {
      onNotificationClick(payload);
      print('Notification Clicked' + payload);
      // _configureSelectNotificationSubject();
    });
  }

  showAlertDialogdelete(BuildContext context) {
    // Create button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    // Create AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Alert"),
      content: Text("Alarm Deleted"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 32, vertical: 64),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Alarm',
            style: TextStyle(
                fontFamily: 'avenir',
                fontWeight: FontWeight.w700,
                color: CustomColors.primaryTextColor,
                fontSize: 24),
          ),
          Expanded(
            child: FutureBuilder<List<AlarmInfo>>(
              future: _alarms,
              builder: (context, snapshot) {
                if (snapshot.hasData)
                  return ListView(
                    children: snapshot.data.map<Widget>((alarm) {
                      var alarmTime =
                          DateFormat('hh:mm aa').format(alarm.alarmDateTime);
                      var gradientColor = GradientTemplate
                          .gradientTemplate[alarm.gradientColorIndex].colors;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 32),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: gradientColor,
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: gradientColor.last.withOpacity(0.4),
                              blurRadius: 8,
                              spreadRadius: 2,
                              offset: Offset(4, 4),
                            ),
                          ],
                          borderRadius: BorderRadius.all(Radius.circular(24)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Icon(
                                      Icons.label,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                    SizedBox(width: 8),
                                    Text(
                                      alarm.title,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'avenir'),
                                    ),
                                  ],
                                ),
                                Switch(
                                  onChanged: (bool value) {
                                    // Puzzle();
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Puzzle()),
                                    );
                                  },
                                  value: true,
                                  activeColor: Colors.white,
                                ),
                              ],
                            ),
                            Text(
                              'Mon-Fri',
                              style: TextStyle(
                                  color: Colors.white, fontFamily: 'avenir'),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  alarmTime,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'avenir',
                                      fontSize: 24,
                                      fontWeight: FontWeight.w700),
                                ),
                                IconButton(
                                  icon: Icon(Icons.delete),
                                  color: Colors.white,
                                  onPressed: () {
                                    _alarmHelper.delete(alarm.id);
                                    cancelNotification('0');
                                    deleteMessage();
                                    loadAlarms();
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    }).followedBy([
                      if (alarms.length < 5)
                        DottedBorder(
                          strokeWidth: 2,
                          color: CustomColors.clockOutline,
                          borderType: BorderType.RRect,
                          radius: Radius.circular(24),
                          dashPattern: [5, 4],
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: CustomColors.clockBG,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(24)),
                            ),
                            child: FlatButton(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 32, vertical: 16),
                              onPressed: () {
                                _alarmTimeString =
                                    DateFormat('HH:mm').format(DateTime.now());
                                showModalBottomSheet(
                                  useRootNavigator: true,
                                  context: context,
                                  clipBehavior: Clip.antiAlias,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(24),
                                    ),
                                  ),
                                  builder: (context) {
                                    return StatefulBuilder(
                                      builder: (context, setModalState) {
                                        return Container(
                                          padding: const EdgeInsets.all(32),
                                          child: Column(
                                            children: [
                                              FlatButton(
                                                onPressed: () async {
                                                  var selectedTime =
                                                      await showTimePicker(
                                                    context: context,
                                                    initialTime:
                                                        TimeOfDay.now(),
                                                  );
                                                  if (selectedTime != null) {
                                                    final now = DateTime.now();
                                                    var selectedDateTime =
                                                        DateTime(
                                                            now.year,
                                                            now.month,
                                                            now.day,
                                                            selectedTime.hour,
                                                            selectedTime
                                                                .minute);
                                                    _alarmTime =
                                                        selectedDateTime;
                                                    setModalState(() {
                                                      _alarmTimeString =
                                                          DateFormat('HH:mm')
                                                              .format(
                                                                  selectedDateTime);
                                                    });
                                                  }
                                                },
                                                child: Text(
                                                  _alarmTimeString,
                                                  style:
                                                      TextStyle(fontSize: 22),
                                                ),
                                              ),
                                              ListTile(
                                                title: Text('Repeat'),
                                                trailing: Icon(
                                                    Icons.arrow_forward_ios),
                                              ),
                                              ListTile(
                                                title: Text('Sound'),
                                                trailing: Icon(
                                                    Icons.arrow_forward_ios),
                                              ),
                                              ListTile(
                                                title: Text('Title'),
                                                trailing: Icon(
                                                    Icons.arrow_forward_ios),
                                              ),
                                              FloatingActionButton.extended(
                                                onPressed: () async {
                                                  DateTime
                                                      scheduleAlarmDateTime;
                                                  if (_alarmTime
                                                      .isAfter(DateTime.now()))
                                                    scheduleAlarmDateTime =
                                                        _alarmTime;
                                                  else
                                                    scheduleAlarmDateTime =
                                                        _alarmTime.add(
                                                            Duration(days: 1));

                                                  var alarmInfo = AlarmInfo(
                                                    alarmDateTime:
                                                        scheduleAlarmDateTime,
                                                    gradientColorIndex:
                                                        alarms.length,
                                                    title: 'Alarm',
                                                  );
                                                  _alarmHelper
                                                      .insertAlarm(alarmInfo);
                                                  scheduleAlarm(
                                                      scheduleAlarmDateTime);
                                                  Navigator.pop(context);
                                                  addMessage();

                                                  loadAlarms();
                                                  if (scheduleAlarmDateTime ==
                                                      DateTime.now()) {
                                                    print('Alarm Ringed...');

                                                    print(
                                                        scheduleAlarmDateTime);
                                                    print(DateTime.now());
                                                    Ringtone.play();
                                                  } else {
                                                    print('Time Crossed');
                                                    print(
                                                        scheduleAlarmDateTime);
                                                    //Ringtone.play();
                                                    print(DateTime.now());
                                                  }
                                                },
                                                icon: Icon(Icons.alarm),
                                                label: Text('Save'),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  },
                                );
                              },
                              child: Column(
                                children: <Widget>[
                                  Image.asset(
                                    'lib/App/Assets/Images/AddAlarm.png',
                                    scale: 1.5,
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Add Alarm',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'avenir'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      else
                        Text('Only 5 alarms allowed!'),
                    ]).toList(),
                  );
                return Center(
                  child: Text(
                    'Loading..',
                    style: TextStyle(color: Colors.white),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future cancelNotification(String payload) async {
    _cancelNotification();
  }

  Future<void> _cancelNotification() async {
    await flutterLocalNotificationsPlugin.cancel(0);
    print('Cancel');
  }

  void printHello() {
    final DateTime now = DateTime.now();
    final int isolateId = Isolate.current.hashCode;
    // ignore: unnecessary_brace_in_string_interps
    print("[$now] Hello, world! isolate=${isolateId} function='$printHello'");
  }

  void androidAlarm() async {
    final int helloAlarmID = 0;
    await AndroidAlarmManager.initialize();
    await AndroidAlarmManager.oneShot(
        const Duration(minutes: 1), helloAlarmID, printHello);
    print('Alarm Fired...');
    FlutterRingtonePlayer.playAlarm();
    //Ringtone.play();
  }

  void scheduleAlarm(DateTime scheduledNotificationDateTime) async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'alarm_notif', 'alarm_notif', 'Channel for Alarm notification',
        icon: 'alarm',
        //sound: RawResourceAndroidNotificationSound('alarm_tone'),
        priority: Priority.High,
        importance: Importance.Max,
        autoCancel: false,
        enableLights: true,
        playSound: true,
        largeIcon: DrawableResourceAndroidBitmap('alarm'));
    // androidAlarm();
    var iOSPlatformChannelSpecifics = IOSNotificationDetails(
        sound: 'thunder_storm',
        presentAlert: true,
        presentBadge: true,
        presentSound: true);

    var platformChannelSpecifics = NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.schedule(0, 'Alarm', 'Hello',
        scheduledNotificationDateTime, platformChannelSpecifics);
    //playAlarm();

    if (scheduledNotificationDateTime == _alarmTime) {
      //  androidAlarm();
      print('Scheduled Notification DateTime...');
      print(scheduledNotificationDateTime);
      print('Current Time :');
      print(_alarmTime);
      androidAlarm();
    } else {
      print('Time Crossed... + Current Time ');
      print(_alarmTime);
      //androidAlarm();
      //print(scheduledNotificationDateTime);
    }
    // print(scheduledNotificationDateTime);
  }
}
