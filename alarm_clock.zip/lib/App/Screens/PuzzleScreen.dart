import 'dart:math';

import 'package:alarm_clock/App/Widgets/ThemeData.dart';
import 'package:flutter/material.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';

void main() {
  runApp(Puzzle());
}

class Puzzle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Random Questions'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;
  final inputController = TextEditingController();
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Random seed = Random();
  int val1 = 0;
  int val2 = 0;
  int sum = 0;

  void randomQuestions() {
    setState(() {
      const int maxval = 100;
      val1 = seed.nextInt(maxval);
      val2 = seed.nextInt(maxval);
      sum = val1 + val2;
    });
  }

  @override
  Widget build(BuildContext context) {
    final inputController = TextEditingController();
    return Scaffold(
      backgroundColor: CustomColors.pageBackgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have refreshed',
            ),
            Text(
              '$val1' '+' '$val2' '=',
              style: Theme.of(context).textTheme.headline4,
            ),
            TextFormField(
              controller: inputController,
              cursorColor: Colors.redAccent[700],
              textAlign: TextAlign.center,
              maxLength: 3,
              autofocus: true,
              keyboardType: TextInputType.number,
              decoration: new InputDecoration(
                  border: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  errorBorder: InputBorder.none,
                  disabledBorder: InputBorder.none,
                  contentPadding:
                      EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
                  hintText: ''),
            ),
            RaisedButton(
              onPressed: () {
                var sumValue = sum.toString();
                var inputValue = inputController.text;
                //  print('Input :' + inputController);
                print('SumValue :' + sumValue);
                print('InputValue :' + inputValue);

                if (sumValue == inputValue) {
                  // print('Input :' + inputController);
                  // print('Sum :' + sum);
                  print('Success');
                  FlutterRingtonePlayer.stop();
                } else {
                  print('Failed');
                  print('Sum :' + sumValue);
                  print('Input :' + inputValue);
                  // print('Input :' + inputController);
                  // print('Sum :' + sum);
                  // FlutterRingtonePlayer.stop();
                }
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: randomQuestions,
        tooltip: 'Increment',
        child: Icon(Icons.refresh),
      ),
    );
  }
}
