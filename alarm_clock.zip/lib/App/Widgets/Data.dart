import 'package:alarm_clock/App/Widgets/EnumsData.dart';
import 'package:alarm_clock/App/Widgets/AlarmInfo.dart';
import 'MenuInfo.dart';

List<MenuInfo> menuItems = [
  MenuInfo(MenuType.clock,
      title: 'Clock', imageSource: 'lib/App/Assets/Images/Clock.png'),
  MenuInfo(MenuType.alarm,
      title: 'Alarm', imageSource: 'lib/App/Assets/Images/AlarmIcon.png'),
  MenuInfo(MenuType.timer,
      title: 'Timer', imageSource: 'lib/App/Assets/Images/TimerIcon.png'),
  MenuInfo(MenuType.stopwatch,
      title: 'Stopwatch',
      imageSource: 'lib/App/Assets/Images/StopwatchIcon.png')
];

List<AlarmInfo> alarms = [
  AlarmInfo(
      alarmDateTime: DateTime.now().add(Duration(hours: 1)),
      title: 'Office',
      gradientColorIndex: 0),
  AlarmInfo(
      alarmDateTime: DateTime.now().add(Duration(hours: 2)),
      title: 'Sport',
      gradientColorIndex: 1),
];
