enum MenuType { alarm, clock, stopwatch, timer }
