import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';
import 'App/Screens/HomeScreen.dart';
import 'App/Widgets/EnumsData.dart';
import 'App/Widgets/MenuInfo.dart';
import 'dart:isolate';
import 'package:android_alarm_manager/android_alarm_manager.dart';
import 'App/Screens/PuzzleScreen.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void notificationClick() {
  // ignore: unused_element
  setOnNotificationClick(Function onNotificationClick) async {
    var initializationSettings;
    await flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String payload) async {
      onNotificationClick(payload);
      print('Notification Clicked' + payload);
    });
  }
}

void printHello() {
  final DateTime now = DateTime.now();
  final int isolateId = Isolate.current.hashCode;
  // ignore: unnecessary_brace_in_string_interps
  print("[$now] Hello, world! isolate=${isolateId} function='$printHello'");
}

void androidAlarm() async {
  final int helloAlarmID = 0;
  //   await AndroidAlarmManager.initialize();
  await AndroidAlarmManager.periodic(
      const Duration(seconds: 5), helloAlarmID, printHello);
  print('Android Alarm...');
}

void main(context) async {
  AndroidAlarmManager.initialize();
  WidgetsFlutterBinding.ensureInitialized();
  var initializationSettingsAndroid = AndroidInitializationSettings('alarm');
  var initializationSettingsIOS = IOSInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
      onDidReceiveLocalNotification:
          (int id, String title, String body, String payload) async {});
  var initializationSettings = InitializationSettings(
      initializationSettingsAndroid, initializationSettingsIOS);
  await flutterLocalNotificationsPlugin.initialize(initializationSettings,
      onSelectNotification: (String payload) async {
    if (payload != null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Puzzle()),
      );
    }
  });
  runApp(MyApp());
}

// Future _configureSelectNotificationSubject() {
//   selectNotificationSubject.stream.listen((String payload) async {
//     await Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => SecondScreen(payload)),
//     );
//   });
// }

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alarm',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ChangeNotifierProvider<MenuInfo>(
        create: (context) => MenuInfo(MenuType.clock),
        child: Home(),
      ),
    );
  }
}
